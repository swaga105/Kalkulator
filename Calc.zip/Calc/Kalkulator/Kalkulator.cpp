﻿// Kalkulator.cpp : Defines the entry point for the application.
//
//klamry - do tworzenia zainicjalizowane zmiennych wewnatrz case
// kalkulator.cpp : Ten plik zawiera funkcję „main”. W nim rozpoczyna się i kończy wykonywanie programu.
//

#include <iostream>
#include <string>
#include<math.h>
#include <vector>


class Calculator {  //klasa bazowa
public:
    virtual ~Calculator() {} //destruktor wirtualny jest używany do zapewnienia usuwanięci pamięci dla obiektów, które są wskaźnikami na klasę bazową
    virtual void calculate() = 0; //metoda która jest dziedziczona w każdej klasie pochodnej
};


class DecCalculator : public Calculator {
public:
    void calculate() override {  //klasa ta dziedziczy po klasie Calculator i przesłania (nadpisuje) metodę calculate() z klasy bazowej
        std::string liczba;
        int podstawa;


        std::cout << "Podaj system liczbowy z ktorego bedziesz przeliczal 16, 8, 2 : ";
        std::cin >> podstawa;

        std::cout << "Podaj liczbe : ";
        std::cin >> liczba;



        int dec = Todec(liczba, podstawa);

        std::cout << "Wartosc dziesietna: " << dec << std::endl;
    }

    int Todec(std::string liczba, int podstawa) {  //funkcja przeliczajaca systemy 16,8,2 na system dziesietny
        int wynik{};
        int d = liczba.length();
        for (int i = 0; i < d; i++) {
            int cyfra = liczba[d - 1 - i] - 48;
            if (cyfra <= 9)
                wynik += cyfra * std::pow(podstawa, i);
            else wynik = wynik + (cyfra - 7) * std::pow(podstawa, i); //dla systemu szesnastkowego trzeba przesunac sie o 55 w tabeli ASCI
        }
        return wynik;
    }
};

class BinaryCalculator : public Calculator {
public:
    void calculate() override {
        std::cout << "Wybierz rodzaj konwersji wpisujac 1, 2 lub 3 :" << std::endl;
        std::cout << "1. Dec to Bin" << std::endl;
        std::cout << "2. Oct to Bin" << std::endl;
        std::cout << "3. Hex to Bin" << std::endl;


        int wybor;
        std::cin >> wybor;

        switch (wybor) {
        case 1:  //wywołanie funkcji przeliczającej z systemu dziesiętnego na dwójkowy
        {
            int dec;
            std::cout << "Podaj liczbe dziesietna: ";
            std::cin >> dec;
            std::cout << "Binarnie: " << decTobin(dec) << std::endl;
            break;
        }
        case 2:  //wywołanie funkcji przeliczającej z systemu ósemkowego na dwójkowy
        { int oct;
        std::cout << "Podaj liczbe osemkowa: ";
        std::cin >> oct;
        std::cout << "Binarnie: " << octToBin(oct) << std::endl;
        break;
        }
        case 3:  //wywołanie funkcji przeliczającej z systemu szesnastkowego na dwójkowy
        {
            std::string hex{};
            std::cout << "Podaj liczbe w systemie szesnastkowym: ";
            std::cin >> hex;

            int decc = hex2dec(hex);  // przeliczanie systemu szesnastkowego na dziesietny by potem przeliczyc z dziesietnego na binarny
            int bin = decTobin(decc);
            std::cout << "W systemie osemkowym: " << bin << std::endl;
            break;
        }

        default:
            std::cout << "Nieprawidlowy wybor." << std::endl;
            break;
        }
    }

private:
    long long decTobin(int n) {  //funkcja zmienia system dziesiętny na binarny
        long long bin = 0;
        int rem, i = 1;

        while (n != 0) {
            rem = n % 2;
            n /= 2;
            bin += rem * i;
            i *= 10;
        }
        return bin;
    }

    int  octToBin(int oct) { // funkcja przeliczajaca system osemkowy na dwojkowy
        int bin{};
        int decimalNumber = 0, i = 0;


        while (oct != 0)
        {
            decimalNumber += (oct % 10) * std::pow(8, i);
            ++i;
            oct /= 10;
        }

        i = 1;

        while (decimalNumber != 0)
        {
            bin += (decimalNumber % 2) * i;
            decimalNumber /= 2;
            i *= 10;
        }
        return bin;
    }

    int hex2dec(std::string hex) //funkcja zmienia system szesnastkowy na dziesietny
    {
        int len = hex.size();
        int dec{}, index{};

        for (int i = len - 1; i >= 0; i--)
        {
            if (hex[i] >= '0' && hex[i] <= '9')
            {
                int digit = int(hex[i]) - 48;
                dec += digit * std::pow(16, index);
                index++;
            }

            else if (hex[i] >= 'A' && hex[i] <= 'F')
            {

                int digit = int(hex[i]) - 55;
                dec += digit * std::pow(16, index);
                index++;
            }
        }
        return dec;
    }


};

class OctalCalculator : public Calculator {
public:
    void calculate() override {

        std::cout << "Wybierz rodzaj konwersji wpisujac 1 lub 2 lub 3 :" << std::endl;
        std::cout << "1. Dec to Octal" << std::endl;
        std::cout << "2. Bin to Octal" << std::endl;
        std::cout << "3. Hex to Octal" << std::endl;

        int wybor;
        std::cin >> wybor;
        switch (wybor) {
        case 1:   //wywołanie funkcji przeliczającej z systemu dziesiętnego na ósemkowy
            int dec;
            std::cout << "Podaj liczbe dziesietna: ";
            std::cin >> dec;
            std::cout << "W systemie osemkowym: " << dec2octal(dec) << std::endl;
            break;

        case 2: {   //wywołanie funkcji przeliczającej z systemu dwójkowego na ósemkowy
            int bin{};
            std::cout << "Podaj liczbe w systemie dwojkowym : ";
            std::cin >> bin;
            std::cout << "W systemie osemkowym: " << bin2octal(bin) << std::endl;
            break;
        }

        case 3: {  //wywołanie dwóch funkcji przeliczających z systemu szesnastkowego na dziesiętnya potem z dziesiętnego na ósemkowy

            std::string hex{};
            std::cout << "Podaj liczbe w systemie szesnastkowym: ";
            std::cin >> hex;

            int decc = hex2dec(hex);  // przeliczanie systemu szesnastkowego na dziesietny by potem przeliczyc z dziesietnego na osemkowy
            int octal = decTooctal(decc);
            std::cout << "W systemie osemkowym: " << octal << std::endl;
            break;
        }
        default:
            std::cout << "Nieprawidlowy wybor";
            break;
        }
    }

private:

    int dec2octal(int dec) // funkcja przeliczajaca system dziesietny na osemkowy
    {
        int rem, i = 1, octalNumber = 0;
        while (dec != 0)
        {
            rem = dec % 8;
            dec /= 8;
            octalNumber += rem * i;
            i *= 10;
        }
        return octalNumber;
    }

    int bin2octal(long long bin)  // funkcja przeliczajaca system dwojkowy na osemkowy
    {
        int octalNumber = 0, decimalNumber = 0, i = 0;

        while (bin != 0)
        {
            decimalNumber += (bin % 10) * std::pow(2, i);
            ++i;
            bin /= 10;
        }

        i = 1;

        while (decimalNumber != 0)
        {
            octalNumber += (decimalNumber % 8) * i;
            decimalNumber /= 8;
            i *= 10;
        }

        return octalNumber;
    }

    int hex2dec(std::string hex) //funkcja zmienia system szesnastkowy na dziesietny
    {
        int len = hex.size();
        int dec{}, index{};

        for (int i = len - 1; i >= 0; i--)
        {
            if (hex[i] >= '0' && hex[i] <= '9')
            {
                int digit = int(hex[i]) - 48;
                dec += digit * std::pow(16, index);
                index++;
            }

            else if (hex[i] >= 'A' && hex[i] <= 'F')
            {

                int digit = int(hex[i]) - 55;
                dec += digit * std::pow(16, index);
                index++;
            }
        }
        return dec;
    }

    int decTooctal(int dec)   //funkcja zmienia system dziesietny na osemkowy
    {
        int rem, i = 1, octal = 0;
        while (dec != 0)
        {
            rem = dec % 8;
            dec /= 8;
            octal += rem * i;
            i *= 10;
        }
        return octal;
    }
};

class HexadecimalCalculator : public Calculator {
public:
    void calculate() override {

        std::cout << "Wybierz rodzaj konwersji wpisujac 1 lub 2 lub 3 :" << std::endl;
        std::cout << "1. Dec to Hex" << std::endl;
        std::cout << "2. Bin to Hex" << std::endl;
        std::cout << "3. Octal to Hex" << std::endl;

        int wybor;
        std::cin >> wybor;
        switch (wybor) {
        case 1: {   //wywołanie funkcji przeliczającej z systemu dziesiętnego na szesnastkowy
            int dec_num{};
            std::cout << " Wpisz liczbe dziesietna: ";
            std::cin >> dec_num;
            std::cout << "W postacie szesnastkowej jest to : " << dec2hex(dec_num) << std::endl;
            break;
        }

        case 2: {  //wywołanie dwóch funkcji przeliczających z systemu dwójkowego na dziesietny a potem z dziesietnego na szesnastkowy
            int bin;
            std::cout << "Wprowadz liczbe w postaci binarnej: ";
            std::cin >> bin;
            int dec = bin2dec(bin);  //przeliczanie z systemu dwojkowego na dziesietny by potem przeliczyc z dziesietnego na szesnastkowy
            std::string hex = dec2hex(dec);
            std::cout << "W postacie szesnastkowej jest to : " << hex << std::endl;
            break;
        }
        case 3: { //wywołanie dwóch funkcji przeliczających z systemu osemkowego na dziesietny a potem z dziesietnego na szesnastkowy

            int oct;
            std::cout << "Wprowadz liczbe w postaci osemkowej: ";
            std::cin >> oct;
            int dec = oct2dec(oct);  //przeliczanie z systemu osemkowego na dziesietny by potem przeliczyc z dziesietnego na szesnastkowy
            std::string hex = dec2hex(dec);
            std::cout << "W postacie szesnastkowej jest to : " << hex << std::endl;
            break;
        }
        default:
            std::cout << "Nieprawidlowy wybor";
            break;
        }
    }

private:

    std::string dec2hex(int dec_num) { //funkcja przeliczajaca z systemu dziesietnego na szesnastkowy
        int r{};
        std::string hex{};
        char num[] = { '0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F' };


        while (dec_num > 0)
        {
            r = dec_num % 16;
            hex = num[r] + hex;
            dec_num = dec_num / 16;
        }
        return hex;
    }

    int bin2dec(int bin) {   //funkcja przeliczajaca z systemu dwojkowego na dziesietny
        int dec = 0, i = 0, rem;

        while (bin != 0) {
            rem = bin % 10;
            bin /= 10;
            dec += rem * std::pow(2, i);
            ++i;
        }
        return dec;
    }

    int oct2dec(int oct)  //funkcja przeliczajaca z systemu osemkowego na dziesietny
    {
        int decimal{}, i{}, num;
        while (oct != 0)
        {
            num = oct % 10;
            oct /= 10;
            decimal += num * std::pow(8, i);
            ++i;
        }
        return decimal;
    }
};

class FloatingPointCalculator : public Calculator {
public:
    void calculate() override {

        std::cout << "Wybierz operacje wpisujac 1 lub 2 lub 3 :" << std::endl;
        std::cout << "1. Dodawanie" << std::endl;
        std::cout << "2. Odejmowanie" << std::endl;
        std::cout << "3. Mnozenie" << std::endl;
        std::cout << "4. Dzielenie" << std::endl;
        std::cout << "5. Potegowanie" << std::endl;
        std::cout << "6. Pierwiastkowanie" << std::endl;

        int wybor;
        std::cin >> wybor;
        switch (wybor) {
        case 1: {  //wywołanie funkcji sumującej
            int iloscLiczb;
            std::cout << "Podaj ilosc liczb do zsumowania: ";
            std::cin >> iloscLiczb;

            std::vector<double> liczby;
            for (int i = 0; i < iloscLiczb; i++) {  //petla dodajaca podane liczby do wektora "liczby"
                double liczba;
                std::cout << "Podaj liczbe:  " << i + 1 << ": ";
                std::cin >> liczba;
                liczby.push_back(liczba);
            }

            double suma = sum(liczby);
            std::cout << "Suma liczb: " << suma << std::endl;
            break;
        }

        case 2: {  //wywołanie funkcji odejmującej

            double a{}, b{};
            std::cout << "Podaj liczbe: ";
            std::cin >> a;
            std::cout << "Podaj liczbe: ";
            std::cin >> b;

            double roznica = sub(a, b);
            std::cout << "Roznica liczb: " << roznica << std::endl;
            break;
        }
        case 3: {  //wywołanie funkcji mnożącej

            int iloscLiczb{};
            std::cout << "Podaj ilosc liczb do pomnozenia: ";
            std::cin >> iloscLiczb;

            std::vector<double> liczby(iloscLiczb);
            for (int i = 0; i < iloscLiczb; ++i) {
                std::cout << "Podaj liczbe " << i + 1 << ": ";
                std::cin >> liczby[i];
            }

            double wynik = multi(liczby);
            std::cout << "Wynik mnozenia: " << wynik << std::endl;
            break;

        }
        case 4:  //wywołanie funkcji dzielącej
        {
            double liczba1, liczba2;

            std::cout << "Podaj liczbe: ";
            std::cin >> liczba1;

            std::cout << "Podaj liczbe: ";
            std::cin >> liczba2;

            double wynik = division(liczba1, liczba2);
            std::cout << "Wynik : " << wynik << std::endl;
            break;
        }

        case 5: { //wywołanie funkcji potegującej 

            double liczba;
            int potega;

            std::cout << "Podaj liczbe: ";
            std::cin >> liczba;

            std::cout << "Podaj potege: ";
            std::cin >> potega;

            double wynik = power(liczba, potega);
            std::cout << "Wynik: " << wynik << std::endl;
            break;
        }
        case 6: {  //wywołanie funkcji pierwiatkującej

            double liczba;

            std::cout << "Podaj liczbe: ";
            std::cin >> liczba;

            double wynik = sqrt(liczba);
            std::cout << "Wynik: " << wynik << std::endl;
            break;
        }
        }
    }

private:

    double sum(std::vector<double> liczby) { //funkcja sumująca
        double suma = 0.0;
        for (const auto liczba : liczby) {
            suma += liczba;
        }
        return suma;
    }

    double sub(double liczba1, double liczba2) { //funkcja odejmująca
        return liczba1 - liczba2;
    }

    double multi(std::vector<double> liczby) {  //funkcja mnożąca
        double wynik = 1.0;
        for (const auto liczba : liczby) {
            wynik = wynik * liczba;
        }
        return wynik;
    }

    double division(double liczba1, double liczba2) {  // funkcja dzieląca
        if (liczba2 != 0) {
            return liczba1 / liczba2;
        }
        else {
            std::cout << "Dzielenie przez zero" << std::endl;
            return 0.0;
        }
    }

    double power(double liczba, int potega) { // funkcja potegująca
        return std::pow(liczba, potega);
    }

    double sqrt(double liczba) {  // funkcja pierwiastkująca
        return std::sqrt(liczba);
    }
};


class CalculatorFactory {
public:
    Calculator* ourCalculator(std::string system) {
        if (system == "bin") {
            return new BinaryCalculator();
        }
        else if (system == "dec") {
            return new DecCalculator();
        }
        else if (system == "oct") {
            return new OctalCalculator();
        }
        else if (system == "hex") {
            return new HexadecimalCalculator();
        }
        else if (system == "float") {
            return new FloatingPointCalculator();
        }
        else {
            return nullptr;
        }
    }
};

int main()
{
    CalculatorFactory factory;
    std::string system;
    std::cout << "Podaj system na ktory chcesz przeliczyc (dec/bin/oct/hex/float): ";
    std::cin >> system;

    Calculator* calculator = factory.ourCalculator(system);
    if (calculator) {
        calculator->calculate();
        delete calculator;
    }
    else {
        std::cout << "Nieprawidłowy system." << std::endl;
    }


    return 0;
}
